package com.espejo.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

@Suppress("OVERRIDE_DEPRECATION")
class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: AppAdapter
    private lateinit var speedView: TextView
    private lateinit var speedBar: ProgressBar
    private lateinit var bgView: ImageView
    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }
    private lateinit var favViews: List<ImageView>
    private var apps: List<AppInfo> = emptyList()

    // Apps sugeridas por defecto para los 4 favoritos (se usan las que estén instaladas)
    private val defaults = listOf(
        "com.google.android.projection.gearhead", // Android Auto
        "com.google.android.apps.maps",
        "com.waze",
        "com.spotify.music",
        "com.google.android.apps.youtube.music",
        "com.android.settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        speedView = findViewById(R.id.speed)
        speedBar = findViewById(R.id.speedBar)
        bgView = findViewById(R.id.bg)
        loadWallpaper()
        findViewById<TextView>(R.id.btnBg).apply {
            setOnClickListener { pickImage.launch(arrayOf("image/*")) }
            setOnLongClickListener {
                File(filesDir, "bg.jpg").delete()
                bgView.setImageDrawable(null)
                Toast.makeText(this@MainActivity, "Fondo quitado", Toast.LENGTH_SHORT).show()
                true
            }
        }
        favViews = listOf(R.id.fav0, R.id.fav1, R.id.fav2, R.id.fav3).map { findViewById<ImageView>(it) }

        adapter = AppAdapter(
            onClick = { launch(it.pkg) },
            onLongClick = { askFavorite(it) }
        )
        val dm = resources.displayMetrics
        val rows = ((dm.heightPixels / dm.density) / 120).toInt().coerceIn(2, 4)
        findViewById<RecyclerView>(R.id.apps).apply {
            layoutManager = GridLayoutManager(this@MainActivity, rows, RecyclerView.HORIZONTAL, false)
            adapter = this@MainActivity.adapter
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        renderDock()
        startSpeed()
    }

    override fun onPause() {
        super.onPause()
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(this)
        } catch (_: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    // Un launcher no debe cerrarse con "atrás"
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private fun loadWallpaper() {
        val f = File(filesDir, "bg.jpg")
        if (f.exists()) bgView.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
    }

    private fun saveWallpaper(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) return
            File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            bgView.setImageBitmap(bmp)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        adapter.submit(apps)
    }

    private fun renderDock() {
        val installed = apps.map { it.pkg }.toSet()
        val fallback = defaults.filter { it in installed }.toMutableList()
        favViews.forEachIndexed { i, view ->
            var pkg = prefs.getString("fav$i", null)
            if (pkg == null || pkg !in installed) {
                pkg = fallback.firstOrNull { p -> favViews.indices.none { j -> prefs.getString("fav$j", null) == p } }
                    ?: fallback.getOrNull(i)
            }
            val app = apps.firstOrNull { it.pkg == pkg }
            if (app != null) {
                view.setImageDrawable(app.icon)
                view.setOnClickListener { launch(app.pkg) }
            } else {
                view.setImageDrawable(null)
                view.setOnClickListener(null)
            }
        }
    }

    private fun askFavorite(app: AppInfo) {
        AlertDialog.Builder(this)
            .setTitle("Poner ${app.label} en favoritos")
            .setItems(arrayOf("Posición 1", "Posición 2", "Posición 3", "Posición 4")) { _, which ->
                prefs.edit().putString("fav$which", app.pkg).apply()
                renderDock()
            }
            .show()
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startSpeed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        } catch (_: Exception) {}
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        startSpeed()
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) (location.speed * 3.6f).toInt() else 0
        speedView.text = kmh.toString()
        speedBar.progress = kmh
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { speedView.text = "--"; speedBar.progress = 0 }
}
